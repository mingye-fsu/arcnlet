Rename the following two files:

ArcNLET.msi_rename   --->  ArcNLET.msi
setup.exe_rename     --->  setup.exe